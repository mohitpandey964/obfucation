﻿using MyUtility;
using System;

// See https://aka.ms/new-console-template for more information

label:

Console.WriteLine("Enter your password");
string? password = Console.ReadLine();

if(!string.IsNullOrEmpty(password))
{
    if(Helper.ValidatePassword(password))
    {
        Console.WriteLine("Valid User");
    }
    else
    {
        Console.WriteLine("Not Valid User");
    }
    Console.ReadKey();
}
else
{
    goto label;
}


