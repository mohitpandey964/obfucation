﻿namespace MyUtility
{
    public static class Helper
    {
        public static bool ValidatePassword(string password)
        {
            if (string.Compare(password, "arvind") == 0 )
                return true;
            return false;
        }
    }
}